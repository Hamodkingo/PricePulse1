import Link from "next/link";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <div className="max-w-3xl space-y-6">
        <span className="inline-block rounded-full bg-emerald-500/10 px-4 py-1.5 text-sm font-medium text-emerald-400 border border-emerald-500/20">
          PricePulse AI — Automated Price Intelligence
        </span>
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">
          Monitor Competitor Prices in Real Time
        </h1>
        <p className="text-lg text-zinc-400">
          Track any online store product link, visualize 30-day price trends, and receive instant Telegram alerts whenever prices drop.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <Link
            href="/dashboard"
            className="rounded-lg bg-emerald-500 px-6 py-3 font-semibold text-zinc-950 hover:bg-emerald-400 transition"
          >
            Open Dashboard
          </Link>
        </div>
      </div>
    </main>
  );
}
